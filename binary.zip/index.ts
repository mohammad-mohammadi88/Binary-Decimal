#!/usr/bin/env tsx

import combination from "./combination";

console.log(combination(13, 21, 3));
console.log(combination(16, 4, 4));
console.log(combination(108, 53, 7));
console.log(combination(15, 37, 9));

// import binaryToDecimal from "./binaryToDecimal";

// console.log(binaryToDecimal("1021", 3));

// import decimalToBinary from "./decimalToBinary";

// console.log(decimalToBinary(21, 3));
